package com.assignment_3;


public class Guitar_3_1_2 extends Instrument_3_1_1 {

	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

}