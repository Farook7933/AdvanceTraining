package com.assignment_3;

import java.util.Random;

public class Assignment_3_1_5 {

	public static void main(String[] args) {
		Instrument_3_1_1[] instruments = new Instrument_3_1_1[10];
		
		Random rand = new Random();
	    
	    for (int i = 0; i < 10; i++) {
	    	int randomNum = rand.nextInt((3 - 1) + 1) + 1;
	    	
	    	if (randomNum == 1)
	    		instruments[i] = new Piano_3_1_4();
	    	else if (randomNum == 2)
	    		instruments[i] = new Flute_3_1_3();
	    	else if (randomNum == 3)
	    		instruments[i] = new Guitar_3_1_2();
	    	
	    	instruments[i].play();
	    }
	    
	    for (int i = 0; i < 10; i++) {
	    	if (instruments[i] instanceof Piano_3_1_4) 
	    		System.out.println("Piano is stored at index " + i);
	    	else if (instruments[i] instanceof Flute_3_1_3) 
	    		System.out.println("Flute is stored at index " + i);
	    	else if (instruments[i] instanceof Guitar_3_1_2) 
	    		System.out.println("Guitar is stored at index " + i);
	    }

	}

}