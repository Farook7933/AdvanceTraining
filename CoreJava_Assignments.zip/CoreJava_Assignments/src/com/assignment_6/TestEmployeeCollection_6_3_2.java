package com.assignment_6;

import java.util.Vector;
public class TestEmployeeCollection_6_3_2 {
	
		public static void main(String[] args) {
			Vector<Employee_6_3_1> v=addInput();
			display(v);

		}
	private static void display(Vector<Employee_6_3_1> v) {
			for(Employee_6_3_1 e:v) {
				System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
			}
			
		}
	private static Vector<Employee_6_3_1>addInput(){
		Employee_6_3_1 e1=new Employee_6_3_1(101,"farook","Chennai");
		Employee_6_3_1 e2=new Employee_6_3_1(102,"idris","NewYork");
		Employee_6_3_1 e3=new Employee_6_3_1(103,"subhani","Texas");
		Vector<Employee_6_3_1> v= new Vector<Employee_6_3_1>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
		
	}
	}